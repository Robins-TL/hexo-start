---
title: NexT主题切换及常用配置
date: 2019-10-25 01:48:25
categories:
tags:
- hexo
- hexo-themes
---

### 官网主要配置
http://theme-next.iissnan.com/getting-started.html#theme-settings

### 搜索功能
http://theme-next.iissnan.com/third-party-services.html#local-search

### 标签和分类配置
https://hexo.io/zh-cn/docs/front-matter.html#%E5%88%86%E7%B1%BB%E5%92%8C%E6%A0%87%E7%AD%BE

### 背景动画效果
https://github.com/theme-next/theme-next-canvas-nest

### 设置友情链接

links

